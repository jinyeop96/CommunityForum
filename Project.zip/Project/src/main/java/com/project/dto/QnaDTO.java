package com.project.dto;

public class QnaDTO {
	private int seq;
	private String title;
	private String name;
	private String qna_content;
	private String qna_reply;
	private String pw;
	
	public int getSeq() {
		return seq;
	}
	
	public void setSeq(int seq) {
		this.seq = seq;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getQna_content() {
		return qna_content;
	}
	
	public void setQna_content(String qna_content) {
		this.qna_content = qna_content;
	}
	
	public String getQna_reply() {
		return qna_reply;
	}
	
	public void setQna_reply(String qna_reply) {
		this.qna_reply = qna_reply;
	}
	
	public String getPw() {
		return pw;
	}
	
	public void setPw(String pw) {
		this.pw = pw;
	}
	
	
	
}
