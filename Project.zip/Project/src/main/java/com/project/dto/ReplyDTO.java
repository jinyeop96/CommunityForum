package com.project.dto;

public class ReplyDTO {
	private int reply_no;
	private int reply_group;
	private int reply_step;
	private int reply_indent;
	private String reply_nickname;
	private String reply_content;
	private int reply_like;
	private int reply_dislike;
	private String reply_date;
	
	public int getReply_no() {
		return reply_no;
	}
	public void setReply_no(int reply_no) {
		this.reply_no = reply_no;
	}
	public int getReply_group() {
		return reply_group;
	}
	public void setReply_group(int reply_group) {
		this.reply_group = reply_group;
	}
	public int getReply_step() {
		return reply_step;
	}
	public void setReply_step(int reply_step) {
		this.reply_step = reply_step;
	}
	public int getReply_indent() {
		return reply_indent;
	}
	public void setReply_indent(int reply_indent) {
		this.reply_indent = reply_indent;
	}
	public String getReply_nickname() {
		return reply_nickname;
	}
	public void setReply_nickname(String reply_nickname) {
		this.reply_nickname = reply_nickname;
	}
	public String getReply_content() {
		return reply_content;
	}
	public void setReply_content(String reply_content) {
		this.reply_content = reply_content;
	}
	public int getReply_like() {
		return reply_like;
	}
	public void setReply_like(int reply_like) {
		this.reply_like = reply_like;
	}
	public int getReply_dislike() {
		return reply_dislike;
	}
	public void setReply_dislike(int reply_dislike) {
		this.reply_dislike = reply_dislike;
	}
	public String getReply_date() {
		return reply_date;
	}
	public void setReply_date(String reply_date) {
		this.reply_date = reply_date;
	}
	
	
}
