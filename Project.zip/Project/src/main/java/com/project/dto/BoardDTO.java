package com.project.dto;

public class BoardDTO {
	private int board_reply;
	private String board_type;
	private int board_no;
	private String board_nickname;
	private String board_title;
	private String board_content;
	private int board_view;
	private int board_like;
	private int board_dislike;
	private String board_date;
	private int board_hasFile;
	private String board_upBoard;
	
	
	
	
	
	
	public String getBoard_upBoard() {
		return board_upBoard;
	}
	public void setBoard_upBoard(String board_upBoard) {
		this.board_upBoard = board_upBoard;
	}
	public int getBoard_hasFile() {
		return board_hasFile;
	}
	public void setBoard_hasFile(int board_hasFile) {
		this.board_hasFile = board_hasFile;
	}
	public int getBoard_reply() {
		return board_reply;
	}
	public void setBoard_reply(int board_reply) {
		this.board_reply = board_reply;
	}
	public String getBoard_type() {
		return board_type;
	}
	public void setBoard_type(String board_type) {
		this.board_type = board_type;
	}
	public int getBoard_no() {
		return board_no;
	}
	public void setBoard_no(int board_no) {
		this.board_no = board_no;
	}
	public String getBoard_nickname() {
		return board_nickname;
	}
	public void setBoard_nickname(String board_nickname) {
		this.board_nickname = board_nickname;
	}
	public String getBoard_title() {
		return board_title;
	}
	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}
	public String getBoard_content() {
		return board_content;
	}
	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}
	public int getBoard_view() {
		return board_view;
	}
	public void setBoard_view(int board_view) {
		this.board_view = board_view;
	}
	public int getBoard_like() {
		return board_like;
	}
	public void setBoard_like(int board_like) {
		this.board_like = board_like;
	}
	public int getBoard_dislike() {
		return board_dislike;
	}
	public void setBoard_dislike(int board_dislike) {
		this.board_dislike = board_dislike;
	}
	public String getBoard_date() {
		return board_date;
	}
	public void setBoard_date(String board_date) {
		this.board_date = board_date;
	}
	
	
	
}
